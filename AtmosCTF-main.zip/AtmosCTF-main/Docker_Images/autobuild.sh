!#/bin/bash
#sudo docker kill CVE IDE WebServer
#sudo docker rm CVE IDE WebServer
sudo docker-compose -f /home/labatrix01/Docker_Images/docker-compose.yml up --force-recreate