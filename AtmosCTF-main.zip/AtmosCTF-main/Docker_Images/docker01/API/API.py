from flask import Flask, jsonify, request, make_response, abort
from flask_restful import Api, Resource
import jwt
import datetime
from functools import wraps


app = Flask(__name__)
api = Api(app)

data = {
"keith":{"name":"Keith Davis","age":19,"phone number":46209451,"username":"keith","password":"keith46209451"},
"kathryn":{"name":"Kathryn Torres","age":50,"phone number":12017309831,"username":"kathryn","password":"123456"},
"andrew":{"name":"Andrew Richardson","age":30,"phone number":12013319946,"username":"andrew","password":"123andrew456"},
"anthony":{"name":"Anthony Kelly","age":27,"phone number":463356423,"username":"anthony","password":"freedom"},
"mark":{"name":"Mark Clark","age":29,"phone number":12019484345,"username":"mark","password":"testing"},
"paul":{"name":"Paul Johnson","age":22,"phone number":12017309424,"username":"paul","password":"football"},
"joseph":{"name":"Joseph Simmons","age":32,"phone number":12016144808,"username":"joseph","password":"000000"},
"peggy":{"name":"Peggy Taylor","age":42,"phone number":12015976127,"username":"peggy","password":"aaaaaa"},
"steven":{"name":"Steven Brown","age":25,"phone number":12018491990,"username":"steven","password":"carlos"},
"carl":{"name":"Carl Patterson","age":36,"phone number":12014222773,"username":"carl","password":"welcome","github":"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"},
"wanda":{"name":"Wanda Gonzalez","age":34,"phone number":12016769717,"username":"wanda","password":"writer"},
"justin":{"name":"Justin Wood","age":21,"phone number":12014222748,"username":"justin","password":"alejandra"},
"jerry":{"name":"Jerry Sanchez","age":52,"phone number":12013316679,"username":"jerry","password":"shit"},
"tiffany":{"name":"Tiffany Lopez","age":27,"phone number":3225885411,"username":"tiffany","password":"anthony"},
"robert":{"name":"Robert Martin","age":44,"phone number":3225885409,"username":"robert","password":"princess"},
"julia":{"name":"Julia Nelson","age":64,"phone number":468139942,"username":"julia","password":"zxczxc"},
"matthew":{"name":"Matthew Jackson","age":18,"phone number":3225885407,"username":"matthew","password":"password1"},
"dennis":{"name":"Dennis Hayes","age":26,"phone number":12012018710,"username":"dennis","password":"654321"},
"rosa":{"name":"Rosa Adams","age":25,"phone number":12022350887,"username":"rosa","password":"password"},
"sara":{"name":"Sara Perez","age":27,"phone number":12014799186,"username":"sara","password":"internet"},
"lori":{"name":"Lori Bell","age":32,"phone number":12013802986,"username":"lori","password":"jennifer"},
"jose":{"name":"Jose Diaz","age":28,"phone number":12013618497,"username":"jose","password":"cheese"},
"james":{"name":"James Martinez","age":29,"phone number":12014222712,"username":"james","password":"andrea"},
"jacqueline":{"name":"Jacqueline Ross","age":34,"phone number":468241626,"username":"jacqueline","password":"loveme"},
"andrea":{"name":"Andrea Thomas","age":22,"phone number":12014775509,"username":"andrea","password":"beatriz"},
"david":{"name":"David King","age":26,"phone number":3225885408,"username":"david","password":"1234567"},
"christopher":{"name":"Christopher Parker","age":44,"phone number":12022814181,"username":"christopher","password":"pokemon"},
"grace":{"name":"Grace Hill","age":36,"phone number":12013080048,"username":"grace","password":"merlin"},
"gerald":{"name":"Gerald Harris","age":21,"phone number":46209451,"username":"gerald","password":"babygirl"},
"scott":{"name":"Scott Lewis","age":32,"phone number":12015089271,"username":"scott","password":"flower"},
"bonnie":{"name":"Bonnie Morris","age":24,"phone number":12019772861,"username":"bonnie","password":"angel"},
"annie":{"name":"Annie Moore","age":32,"phone number":461147242,"username":"annie","password":"jordan"},
"henry":{"name":"Henry Turner","age":24,"phone number":12018577757,"username":"henry","password":"soccer"},
"emily":{"name":"Emily Garcia","age":23,"phone number":12013897327,"username":"emily","password":"monkey"},
"norma":{"name":"Norma Russell","age":34,"phone number":12017194893,"username":"norma","password":"passport"},
"paula":{"name":"Paula Wright","age":35,"phone number":12014222730,"username":"paula","password":"mustang"},
"ryan":{"name":"Ryan Peterson","age":37,"phone number":12016494261,"username":"ryan","password":"zxcvbnm"},
"jason":{"name":"Jason Evans","age":27,"phone number":12016544309,"username":"jason","password":"alberto"},
"louise":{"name":"Louise Hall","age":29,"phone number":12022800587,"username":"louise","password":"starwars"},
"dev":{"name":"Development Lead","username":"dev_user","password":"DE3v3l0perISR3@L!!"},
"kenneth":{"name":"Kenneth Wilson","age":54,"phone number":12018857614,"username":"kenneth","password":"trustno1"},
"thomas":{"name":"Thomas Gray","age":32,"phone number":12013797889,"username":"thomas","password":"iloveyou"},
"stephen":{"name":"Stephen Watson","age":43,"phone number":12018904538,"username":"stephen","password":"ashley"},
"tracy":{"name":"Tracy Collins","age":46,"phone number":12012938236,"username":"tracy","password":"killer"},
"lois":{"name":"Lois Rogers","age":38,"phone number":12022097939,"username":"lois","password":"asdf"},
"anne":{"name":"Anne Miller","age":42,"phone number":12012857811,"username":"anne","password":"jesus"},
"dawn":{"name":"Dawn Rivera","age":20,"phone number":462361439,"username":"dawn","password":"sebastian"},
"jonathan":{"name":"Jonathan Rodriguez","age":22,"phone number":12022900051,"username":"jonathan","password":"lovely"},
"rachel":{"name":"Rachel Sanders","age":31,"phone number":12013653471,"username":"rachel","password":"charlie"},
"douglas":{"name":"Douglas Bennett","age":23,"phone number":12018015695,"username":"douglas","password":"whatever"},
"harold":{"name":"Harold Smith","age":34,"phone number":12014167483,"username":"harold","password":"12345678"},
}

app.config['SECRET_KEY'] = 'ThisN@t0FyourBusin355'

def token_required(f):
	@wraps(f)
	def decorated(*args, **kwargs):
		token = request.args.get('token')

		if not token:
			return jsonify({'message':'Token is missing! Please check the parameters and the token.'})

		try:
			data =  jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
		except:
			return jsonify({'message':'Token is invalid!'})

		return f(*args, **kwargs)

	return decorated


@app.route('/login')
def login():
	auth = request.authorization

	if auth and auth.password == 'WAT@Str0ngPass' and auth.username == 'administrator':
		token = jwt.encode({'user':auth.username, 'exp':datetime.datetime.utcnow() + datetime.timedelta(hours=24)}, app.config['SECRET_KEY'])

		return jsonify({'token':token})


	return make_response('Could not verify!',401,{'WWW-Authenticate':'Baisc realm="Login Required"'})

class UsersData(Resource):
	@token_required
	def get(self, uname,):
		if uname not in data:
			abort(make_response(jsonify(message="User not found"),404))

		return data[uname]

api.add_resource(UsersData, "/employees/<string:uname>")

if __name__ == '__main__':
	app.run(host='0.0.0.0')
