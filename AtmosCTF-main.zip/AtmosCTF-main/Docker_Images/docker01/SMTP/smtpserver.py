import smtpd
import asyncore
import os

class CustomSMTPServer(smtpd.SMTPServer):
    
    def process_message(self, peer, mailfrom, rcpttos, data):
        print 'Receiving message from:', peer
        print 'Message addressed from:', mailfrom
        print 'Message addressed to  :', rcpttos
        print 'Message length        :', len(data)
        #return
        print data

        senderip = peer[0]
        #senderip = "192.168.0.10"
        data = data.lower()
        if mailfrom == "stevenbrown@labatrix.com" and rcpttos[0] == "carlpatterson@labatrix.com" and "json" in data:
            command = "python3 '/SMTP/sendthefile.py' {}".format(senderip)
            os.system(command)



server = CustomSMTPServer(('0.0.0.0', 25), None)

asyncore.loop()
