import requests
import json

source = "http://172.20.0.10:5000/login"
r = requests.get(source, auth=('administrator','WAT@Str0ngPass'))
r_dic = json.loads(r.text)

data = """
[
{"email": "tristique.neque.venenatis@hotmail.ca","phone": "1-266-218-1146","name": "Germane Meyer"},
{"email": "quam.a.felis@yahoo.com","phone": "1-738-234-7772","name": "Brooke Mcconnell"},
{"email": "eget.metus@icloud.couk","phone": "(458) 585-3137","name": "Lee Wood"},
{"email": "eget@aol.org","phone": "1-570-554-7582","name": "Gavin Maynard"},
{"email": "ornare@aol.couk","phone": "1-815-331-5364","name": "Rebecca Burton"},
{"email": "convallis.dolor@google.ca","phone": "1-793-854-5284","name": "Quamar Jennings"},
{"email": "ac.mattis@aol.org","phone": "1-860-777-2624","name": "Kristen Grant"},
{"email": "sodales@icloud.net","phone": "(353) 597-6926","name": "Nola Cash"},
{"email": "metus.urna.convallis@google.com","phone": "1-882-239-2607","name": "Avram Campbell"},
{"email": "sociosqu.ad@icloud.ca","phone": "(573) 457-1728","name": "Ethan Miles"},
{"email": "vestibulum.nec.euismod@hotmail.com","phone": "1-182-351-6639","name": "Cameran Rosario"},
{"email": "tellus.lorem.eu@hotmail.com","phone": "1-716-331-6526","name": "Boris Lloyd"},
{"email": "a.facilisis@hotmail.couk","phone": "(681) 116-6484","name": "Lesley Huffman"},
{"email": "mauris.molestie@protonmail.couk","phone": "(353) 207-1776","name": "Stephanie Reeves"},
{"email": "quam.vel@aol.org","phone": "1-477-940-9934","name": "Hamish Terry"},
{"email": "ut.erat@google.org","phone": "1-535-274-7686","name": "Jessica Norris"},
{"email": "jnor@google.org","phone": "1-535-274-7686","name": "Jesy Norris","APIKey":"##################################"},
{"email": "mauris.aliquam@protonmail.net","phone": "(863) 174-7881","name": "Dale Cunningham"},
{"email": "pede.blandit@hotmail.ca","phone": "(833) 912-1043","name": "Bert Martin"},
{"email": "sapien.aenean@aol.couk","phone": "1-544-589-3374","name": "Warren Steele"},
{"email": "sed.diam@outlook.org","phone": "1-878-952-4136","name": "Bianca Sheppard"}
]"""

data = data.replace("##################################",r_dic["token"])

with open("data.json","w") as datafile:
    datafile.write(data)
print(r_dic["token"])
print("we reached the end")