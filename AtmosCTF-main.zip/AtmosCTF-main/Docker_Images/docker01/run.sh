#!/bin/bash
set -m
python3 /Discussion/discussion_app.py &
python3 /API/API.py &
python2 /SMTP/smtpserver.py &
sleep 5
python3 /SMTP/tokengenerator.py
fg %1