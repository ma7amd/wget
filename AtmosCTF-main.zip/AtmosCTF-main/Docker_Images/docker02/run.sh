#!/bin/bash
set -m
echo 'before running the IDE'
echo 'q#f&EeM?Q+cpJwU7FMw5' | su -c "python3 /home/networkadmin/IDE/manage.py runserver 0.0.0.0:8000" networkadmin &
echo 'after running the IDE'
python3 /manage/thesender.py
echo 'after the sender'
fg %1