#! /bin/bash
set -m
#bash /manage/ssh.sh &
python3 /manage/webserver.py &
service ssh restart
fg %1