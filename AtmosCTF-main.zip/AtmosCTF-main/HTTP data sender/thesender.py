import requests
import random
import time

d1 = {"name": "Courtney Dickerson","email": "quam@protonmail.com","phone": "(162) 126-8624","date": "Feb 1, 2022"}
d2 = {"name": "Drake Thompson","email": "dignissim.maecenas@outlook.org","phone": "1-437-337-5722","date": "Feb 14, 2023"}
d3 = {"name": "Uriel Howe","email": "sagittis.nullam.vitae@hotmail.couk","phone": "1-758-787-6933","date": "Sep 13, 2021"}
d4 = {"name": "William Benton","email": "nec@aol.org","phone": "1-885-882-3019","date": "Jun 29, 2021"}
d5 = {"name": "Samantha Patrick","email": "erat.nonummy.ultricies@yahoo.edu","phone": "(586) 782-3466","date": "Mar 15, 2023"}
d6 = {"name": "Jillian Moody","email": "nec.orci.donec@icloud.com","phone": "1-830-455-4813","date": "Feb 13, 2023"}
d7 = {"name": "Tana Melendez","email": "donec.vitae.erat@hotmail.ca","phone": "1-498-848-1867","date": "Apr 2, 2021"}
d8 = {"name": "Erasmus Ayala","email": "nec.mauris@yahoo.net","phone": "1-238-617-7319","date": "Apr 16, 2022"}
d9 = {"name": "Stephen Petty","email": "eget.volutpat@icloud.org","phone": "1-262-614-3295","date": "May 9, 2022"}
d10 = {"name": "Priscilla Wiley","email": "sollicitudin.orci.sem@google.couk","phone": "(113) 748-9775","date": "Feb 9, 2022"}
d11 = {"name": "Orla Garza","email": "ultricies.ornare@yahoo.net","phone": "1-370-468-6448","date": "May 29, 2021"}
d12 = {"name": "Leonard Ruiz","email": "integer.mollis@yahoo.couk","phone": "1-756-748-1873","date": "May 14, 2021"}
d13 = {"name": "Kibo Padilla","email": "magna.et@protonmail.com","phone": "1-705-655-2632","date": "Jan 7, 2022"}
d14 = {"name": "Lillian Preston","email": "magna@aol.org","phone": "(255) 168-2158","date": "Oct 12, 2022"}
d15 = {"name": "Autumn Joyce","email": "per@aol.org","phone": "1-573-823-4129","date": "Oct 2, 2021"}
d16 = {"name": "Joan Lyons","email": "in@google.com","phone": "(372) 414-2824","date": "May 15, 2022"}
d17 = {"name": "Jennifer Diaz","email": "nisi.mauris@yahoo.edu","phone": "(431) 681-8378","date": "Mar 15, 2023"}
d18 = {"name": "Nerea Cleveland","email": "mauris.rhoncus.id@protonmail.couk","phone": "1-212-621-3253","date": "Mar 18, 2023"}
d19 = {"name": "Isabella Holland","email": "augue.eu.tellus@icloud.net","phone": "(367) 617-7264","date": "Feb 28, 2022"}
d20 = {"name": "Dexter Mcgowan","email": "elit.pellentesque@hotmail.couk","phone": "1-169-310-9941","date": "Nov 13, 2022"}
d21 = {"name": "Karina Mccoy","email": "massa.lobortis.ultrices@hotmail.net","phone": "1-573-657-3468","date": "Dec 6, 2022"}
d22 = {"name": "Carl Ferguson","email": "non.enim@hotmail.net","phone": "1-789-547-7314","date": "Jul 17, 2022"}
d23 = {"name": "Patrick Melendez","email": "magna.a@protonmail.couk","phone": "(558) 774-7689","date": "Apr 7, 2021"}
d24 = {"name": "Lila Chang","email": "suspendisse.non@outlook.ca","phone": "(221) 347-9256","date": "Jan 31, 2022"}
d25 = {"name": "Melanie Ramirez","email": "ipsum.primis.in@outlook.org","phone": "1-958-675-4538","date": "Jun 15, 2022"}
d26 = {"name": "Regina Lindsey","email": "sed.libero@aol.org","phone": "(874) 366-7101","date": "Mar 15, 2022"}
d27 = {"name": "Demetrius Soto","email": "fusce.dolor@hotmail.edu","phone": "1-322-598-5277","date": "Aug 10, 2022"}
d28 = {"name": "Cyrus Finley","email": "eleifend.non@outlook.net","phone": "(156) 482-1619","date": "Mar 11, 2022"}
d29 = {"name": "Kirsten Kirkland","email": "ipsum.cursus.vestibulum@icloud.couk","phone": "(867) 318-0266","date": "Dec 6, 2022"}
d30 = {"name": "Miranda Baker","email": "eget@google.edu","phone": "(247) 166-9814","date": "May 24, 2021"}
d31 = {"name": "Melyssa Marshall","email": "ut.dolor@icloud.net","phone": "(653) 697-9173","date": "Apr 2, 2021"}
d32 = {"name": "Dacey Dejesus","email": "tincidunt@aol.couk","phone": "(856) 922-4043","date": "Nov 3, 2022"}
d33 = {"name": "Basia Singleton","email": "magna@google.ca","phone": "1-511-308-3586","date": "Oct 5, 2022"}
d34 = {"name": "Samantha Harding","email": "imperdiet.non@icloud.couk","phone": "(329) 631-6114","date": "Mar 8, 2023"}
d35 = {"name": "Brenden Burnett","email": "fringilla.porttitor@hotmail.net","phone": "(278) 364-3216","date": "May 19, 2022"}
d36 = {"name": "Jameson Holloway","email": "at@icloud.com","phone": "(984) 622-4566","date": "Feb 8, 2023"}
d37 = {"name": "Leigh Huber","email": "tellus.non@google.ca","phone": "(792) 646-1741","date": "Jul 26, 2022"}
d38 = {"name": "Micah Harvey","email": "magnis.dis@icloud.org","phone": "(584) 623-7171","date": "Sep 1, 2021"}
d39 = {"name": "Lawrence Abbott","email": "eget.odio@outlook.com","phone": "1-473-188-6341","date": "Sep 10, 2022"}
d40 = {"name": "Abel Barry","email": "velit@outlook.com","phone": "1-370-583-2664","date": "Jul 7, 2022"}
d41 = {"name": "Vera Solomon","email": "sem.mollis@aol.org","phone": "(357) 834-3899","date": "Apr 23, 2021"}
d42 = {"name": "Daria Howard","email": "feugiat.placerat.velit@protonmail.org","phone": "(222) 549-6558","date": "Nov 2, 2021"}

paramlist = [d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21,d22,d23,d24,d25,d26,d27,d28,d29,d30,d31,d32,d33,d34,d35,d36,d37,d38,d39,d40,d41,d42]
URL = "http://IP:8008/"


while True:
    param_num = random.randint(0,41)
    r = requests.post(url = URL, data = paramlist[param_num])
    time.sleep(4)
