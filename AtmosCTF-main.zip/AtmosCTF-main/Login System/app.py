from flask import (
    Flask,
    g,
    redirect,
    render_template,
    request,
    session,
    url_for
)

class User:
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

    def __repr__(self):
        return f'<User: {self.username}>'


userid = 1
username = "dev_user"
password = "DE3v3l0perISR3@L!!"


app = Flask(__name__)
app.secret_key = 'NoOneKnowsAboutThis123!!'

@app.before_request
def before_request():
    g.user = None

    if 'user_id' in session:
        user = "dev_user"
        g.user = user
        

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        session.pop('user_id', None)

        username = request.form['username']
        password = request.form['password']
        

        if username == "dev_user" and password == "DE3v3l0perISR3@L!!":
            session['user_id'] = userid
            return redirect(url_for('compiler'))

        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/')
def compiler():
    if not g.user:
        return redirect(url_for('login'))

    return redirect('http://www.google.com')

if __name__ == '__main__':
    app.run(host='172.17.0.2', port=8000)