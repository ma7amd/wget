#!/usr/bin/env python3
import smtplib, email, socket
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

port = 25
smtp_server = "192.168.0.10"
receiver_email = "mysender@kali.com"
sender_email = "youreceiver@uckie.com"
subject = "Testing email"
body = "Here is the json file"

message = MIMEMultipart()
message["From"] = sender_email
message["To"] = receiver_email
message["Subject"] = subject
message.attach(MIMEText(body, "plain"))

filename = "/SMTP/data.json"
with open(filename, 'rb') as f:
    part = MIMEBase("application", "octet-stream")
    part.set_payload(f.read())

#encoders.encode_base64(part)
part.add_header(
    "Content-Disposition",
    f"attachment; filename= {filename}",
)
message.attach(part)
text = message.as_string()

with smtplib.SMTP(smtp_server, port) as server:
    server.sendmail(sender_email, receiver_email,text)