#!/usr/bin/env python2
import smtpd
import asyncore
import os

class CustomSMTPServer(smtpd.SMTPServer):
    
    def process_message(self, peer, mailfrom, rcpttos, data):
        print 'Receiving message from:', peer
        print 'Message addressed from:', mailfrom
        print 'Message addressed to  :', rcpttos
        print 'Message length        :', len(data)
        print data

        if "json file" in data:
            os.system("python3 sendthefile.py")


server = CustomSMTPServer(('0.0.0.0', 1025), None)

asyncore.loop()