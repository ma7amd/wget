from django.shortcuts import render
import sys
import re

# Create your views here.

def index(request):
	return render(request, 'home.html')

def runcode(request):
	blacklist = ['os','system','subprocess','exec','!','@','#','$','%','^','&','*']
	if request.method == "POST":
		codeareadata = request.POST['codearea']
		# the blacklist filter
		codefilter = codeareadata.split("\r\n")
		for i in codefilter:
			i1 = re.split(" |\.|\(|\)|,|'",i)
			print(i1)

			for n in i1:
				if n in blacklist:
					print("It's in the blacklist!!!!!")
					codeareadata = ""
			else:
				pass

		try:
			
			original_stdout = sys.stdout
			sys.stdout = open('pyinputs.txt', 'w')


			# execute code
			exec(codeareadata)

			sys.stdout.close()

			sys.stdout = original_stdout # resect the standard output to its original value

			# read output from pyinputs.txt and save it in output variable

			output = open('pyinputs.txt', 'r').read()
		except Exception as e:
			# return errors in the code

			sys.stdout = original_stdout
			output = e


	# return and render index page and send codeareadata and output to show on page

	return render(request, 'home.html', {"code":codeareadata, "output":output})