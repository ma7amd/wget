---
name: Feature request
about: Suggest an idea for this project
title: ""
labels: ""
assignees: ""
---

**Checklist**

- [ ] I read the [README](https://github.com/angristan/openvpn-install/blob/master/README.md)
- [ ] I read the [FAQ](https://github.com/angristan/openvpn-install/blob/master/FAQ.md)
- [ ] I searched the [issues](https://github.com/angristan/openvpn-install/issues?q=is%3Aissue+)
- [ ] My issue is about the script, and not OpenVPN itself

<!---
⚠️
If you need help with OpenVPN itself, please us the [community forums](https://forums.openvpn.net/) or [Stack Overflow](https://stackoverflow.com/questions/tagged/openvpn)
PLEASE OPEN A DISCUSSION INSTEAD: https://github.com/angristan/openvpn-install/discussions
⚠️
--->
